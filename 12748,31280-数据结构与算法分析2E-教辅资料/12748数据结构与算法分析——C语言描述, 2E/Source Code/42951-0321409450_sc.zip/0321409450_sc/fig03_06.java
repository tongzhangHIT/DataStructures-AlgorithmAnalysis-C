    public static <AnyType> void print( Collection<AnyType> coll )
    {
        for( AnyType item : coll )
            System.out.println( item );
    }
