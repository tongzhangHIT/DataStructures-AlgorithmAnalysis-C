    class TreeNode
    {
        Object   element;
        TreeNode firstChild;
        TreeNode nextSibling;
    }
