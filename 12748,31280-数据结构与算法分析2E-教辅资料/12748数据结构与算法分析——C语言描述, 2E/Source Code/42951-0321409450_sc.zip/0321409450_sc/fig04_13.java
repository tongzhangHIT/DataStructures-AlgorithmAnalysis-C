    class BinaryNode
    {
            // Friendly data; accessible by other package routines
        Object     element;      // The data in the node
        BinaryNode left;         // Left child
        BinaryNode right;        // Right child
    }
