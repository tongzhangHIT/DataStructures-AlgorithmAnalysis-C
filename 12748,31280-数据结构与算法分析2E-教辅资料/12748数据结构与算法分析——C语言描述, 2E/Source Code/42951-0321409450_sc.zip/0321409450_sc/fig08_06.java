public class DisjSets
{
    public DisjSets( int numElements )
      { /* Figure 8.7 */ }
    public void union( int root1, int root2 )
      { /* Figures 8.8 and 8.13 */ }
    public int find( int x )
      { /* Figures 8.9 and 8.15 */ }

    private int [ ] s;
}
